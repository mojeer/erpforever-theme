app_name = "erpforever_theme"
app_title = "ERPForever Theme"
app_publisher = "Your Name"
app_description = "ERPForever Custom theme"
app_email = "info@iweb.ps"
app_license = "MIT"

app_include_js = "/assets/remote_theme/js/inject_theme.js"
